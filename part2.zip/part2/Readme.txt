Output contains all the Hadoop outputs from various sources.
Rest Mapper and Reducer are for word-Count
MapperCoOccurrence and reducer are for Word Co-Occurrence.