code contains Code for Data collection
Data contains all the data from different sources
